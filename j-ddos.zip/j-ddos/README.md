# j-ddos

This is a simple java ddos script

Example


javac jddos.java
java jddos